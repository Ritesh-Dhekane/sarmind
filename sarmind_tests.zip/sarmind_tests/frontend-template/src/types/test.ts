export interface Question {
  questionNo: number
  question: string
  optionA: string
  optionB: string
  optionC: string
  optionD: string
  correctAnswer: string
}

export interface ExamType {
  id: string
  name: string
  description: string
  subjects: Subject[]
}

export interface Subject {
  id: string
  name: string
  paperSets: PaperSet[]
}

export interface PaperSet {
  id: string
  name: string
  questionsCount: number
  duration: number // in minutes
  difficulty: 'Easy' | 'Medium' | 'Hard'
} 