import Papa from 'papaparse'
import { Question } from '@/types/test'

export async function readQuestionsFromCSV(examType: string, subject: string, setId: string): Promise<Question[]> {
  try {
    // Convert to uppercase for consistency with folder names
    const examTypeUpper = examType.toUpperCase()
    const response = await fetch(`/data/${examTypeUpper}/${subject}/${setId}.csv`)
    
    if (!response.ok) {
      console.error(`Failed to fetch CSV: ${response.status} ${response.statusText}`)
      throw new Error(`Failed to load questions file (${response.status})`)
    }
    
    const csvText = await response.text()
    
    return new Promise((resolve, reject) => {
      Papa.parse(csvText, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          if (results.errors.length > 0) {
            console.error('CSV parsing errors:', results.errors)
            reject(new Error('Failed to parse questions data'))
            return
          }

          try {
            const questions = results.data.map((row: any, index: number) => {
              if (!row['Question'] || !row['Option A'] || !row['Option B'] || 
                  !row['Option C'] || !row['Option D'] || !row['Correct Answer']) {
                throw new Error(`Invalid question data at index ${index}`)
              }

              return {
                questionNo: parseInt(row['Question no.']) || index + 1,
                question: row['Question'],
                optionA: row['Option A'],
                optionB: row['Option B'],
                optionC: row['Option C'],
                optionD: row['Option D'],
                correctAnswer: row['Correct Answer']
              }
            })
            resolve(questions)
          } catch (error) {
            reject(error)
          }
        },
        error: (error) => {
          console.error('CSV parsing error:', error)
          reject(new Error('Failed to parse questions file'))
        }
      })
    })
  } catch (error) {
    console.error('Error reading CSV:', error)
    throw error
  }
} 