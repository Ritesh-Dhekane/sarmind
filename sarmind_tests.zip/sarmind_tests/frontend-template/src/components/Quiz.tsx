'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'

interface Question {
  question: string
  options: string[]
  correctAnswer: number
}

interface QuizProps {
  testType: string
  subject: string
  paperSet: string
}

export default function Quiz({ testType, subject, paperSet }: QuizProps) {
  const router = useRouter()
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [userAnswers, setUserAnswers] = useState<(number | null)[]>([])
  const [questions, setQuestions] = useState<Question[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadQuestions = async () => {
      try {
        // In a real app, this would be an API call
        const response = await fetch('/data/questionSets.json')
        const data = await response.json()
        setQuestions(data[testType][subject][paperSet] || [])
        setLoading(false)
      } catch (err) {
        setError('Failed to load questions')
        setLoading(false)
      }
    }

    loadQuestions()
  }, [testType, subject, paperSet])

  if (loading) {
    return <div className="flex justify-center items-center min-h-[400px]">Loading...</div>
  }

  if (error) {
    return <div className="text-red-500 text-center">{error}</div>
  }

  const handleSelectAnswer = (index: number) => {
    setSelectedAnswer(index)
    const newAnswers = [...userAnswers]
    newAnswers[currentQuestion] = index
    setUserAnswers(newAnswers)
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
      setSelectedAnswer(userAnswers[currentQuestion - 1])
    }
  }

  const handleNext = () => {
    if (selectedAnswer === null) return

    if (currentQuestion === questions.length - 1) {
      // Calculate score
      const score = userAnswers.reduce((acc, answer, index) => {
        return acc + (answer === questions[index].correctAnswer ? 1 : 0)
      }, 0)
      const percentage = Math.round((score / questions.length) * 100)

      // Navigate to results
      router.push(`/result?score=${score}&total=${questions.length}&percentage=${percentage}`)
    } else {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedAnswer(userAnswers[currentQuestion + 1] ?? null)
    }
  }

  const currentQuestionData = questions[currentQuestion]
  const isLastQuestion = currentQuestion === questions.length - 1

  return (
    <div className="max-w-3xl mx-auto bg-background rounded-lg shadow-lg p-8">
      {/* Progress bar */}
      <div className="mb-8">
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
          <div
            className="bg-primary-500 h-3 rounded-full transition-all duration-300"
            style={{ width: `${((currentQuestion + 1) * 100) / questions.length}%` }}
          />
        </div>
        <div className="text-right text-sm text-gray-600 dark:text-gray-400 mt-2">
          Question {currentQuestion + 1} of {questions.length}
        </div>
      </div>

      {/* Question */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-foreground mb-8">
          {currentQuestionData.question}
        </h2>
        <div className="space-y-4">
          {currentQuestionData.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleSelectAnswer(index)}
              className={`w-full text-left p-6 rounded-xl border-2 transition-all duration-200 text-lg font-medium shadow-sm
                ${
                  selectedAnswer === index
                    ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20 shadow-primary-500/20'
                    : 'border-gray-200 dark:border-gray-700 hover:border-primary-300 hover:bg-gray-50 dark:hover:bg-gray-800'
                }
              `}
            >
              {option}
            </button>
          ))}
        </div>
      </div>

      {/* Navigation buttons */}
      <div className="flex justify-between">
        <button
          onClick={handlePrevious}
          disabled={currentQuestion === 0}
          className="px-8 py-3 rounded-full text-primary-500 border-2 border-primary-500 hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed font-medium"
        >
          Previous
        </button>
        <button
          onClick={handleNext}
          disabled={selectedAnswer === null}
          className="px-8 py-3 rounded-full bg-primary-500 text-white hover:bg-primary-600 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed font-medium shadow-lg shadow-primary-500/30"
        >
          {isLastQuestion ? 'Finish' : 'Next'}
        </button>
      </div>
    </div>
  )
} 