'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function ErrorBoundary({
  error,
  reset,
}: {
  error: Error
  reset: () => void
}) {
  const router = useRouter()

  useEffect(() => {
    console.error('Test Error:', error)
  }, [error])

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
          Something went wrong!
        </h2>
        <p className="text-gray-600 dark:text-gray-400 mb-8">
          {error.message || 'An unexpected error occurred'}
        </p>
        <div className="space-x-4">
          <button
            onClick={() => reset()}
            className="px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600"
          >
            Try again
          </button>
          <button
            onClick={() => router.push('/tests')}
            className="px-4 py-2 border-2 border-primary-500 text-primary-600 rounded-lg hover:bg-primary-50"
          >
            Back to Tests
          </button>
        </div>
      </div>
    </div>
  )
} 