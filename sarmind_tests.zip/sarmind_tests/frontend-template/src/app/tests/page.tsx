'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { ExamType } from '@/types/test'

const examTypes: ExamType[] = [
  {
    id: 'cet',
    name: 'Common Entrance Test (CET)',
    description: 'State level entrance examination for engineering and medical courses',
    subjects: [
      {
        id: 'physics',
        name: 'Physics',
        paperSets: [
          {
            id: 'set1',
            name: 'Set 1 - Mechanics',
            questionsCount: 30,
            duration: 30,
            difficulty: 'Medium'
          },
          {
            id: 'set2',
            name: 'Set 2 - Electromagnetism',
            questionsCount: 30,
            duration: 30,
            difficulty: 'Hard'
          }
        ]
      },
      {
        id: 'chemistry',
        name: 'Chemistry',
        paperSets: [
          {
            id: 'set1',
            name: 'Set 1 - Basic Concepts',
            questionsCount: 30,
            duration: 30,
            difficulty: 'Medium'
          }
        ]
      },
      {
        id: 'mathematics',
        name: 'Mathematics',
        paperSets: [
          {
            id: 'set1',
            name: 'Set 1 - Algebra',
            questionsCount: 30,
            duration: 30,
            difficulty: 'Medium'
          }
        ]
      }
    ]
  },
  {
    id: 'jee',
    name: 'Joint Entrance Examination (JEE)',
    description: 'National level engineering entrance examination',
    subjects: [
      {
        id: 'physics',
        name: 'Physics',
        paperSets: [
          {
            id: 'set1',
            name: 'Set 1 - Advanced Mechanics',
            questionsCount: 25,
            duration: 45,
            difficulty: 'Hard'
          }
        ]
      },
      {
        id: 'chemistry',
        name: 'Chemistry',
        paperSets: [
          {
            id: 'set1',
            name: 'Set 1 - Organic Chemistry',
            questionsCount: 25,
            duration: 45,
            difficulty: 'Hard'
          }
        ]
      }
    ]
  },
  // Add other exam types
]

export default function TestsPage() {
  const router = useRouter()
  const [selectedExam, setSelectedExam] = useState<ExamType | null>(null)
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null)

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white dark:from-gray-900 dark:to-gray-800 py-12">
      <div className="container mx-auto px-4">
        {!selectedExam ? (
          // Exam Type Selection
          <div className="space-y-8">
            <div className="text-center">
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                Select an Examination
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Choose the examination you want to practice for
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {examTypes.map((exam) => (
                <button
                  key={exam.id}
                  onClick={() => setSelectedExam(exam)}
                  className="p-6 bg-white dark:bg-gray-800 rounded-2xl shadow-custom hover:shadow-custom-lg transition-all duration-200 text-left"
                >
                  <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    {exam.name}
                  </h2>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">
                    {exam.description}
                  </p>
                </button>
              ))}
            </div>
          </div>
        ) : !selectedSubject ? (
          // Subject Selection
          <div className="space-y-8">
            <div className="text-center">
              <button
                onClick={() => setSelectedExam(null)}
                className="text-primary-600 hover:text-primary-700 mb-4 inline-flex items-center"
              >
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back to Examinations
              </button>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                {selectedExam.name} Subjects
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Select a subject to view available paper sets
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {selectedExam.subjects.map((subject) => (
                <button
                  key={subject.id}
                  onClick={() => setSelectedSubject(subject.id)}
                  className="p-6 bg-white dark:bg-gray-800 rounded-2xl shadow-custom hover:shadow-custom-lg transition-all duration-200"
                >
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                    {subject.name}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mt-2">
                    {subject.paperSets.length} Paper Sets Available
                  </p>
                </button>
              ))}
            </div>
          </div>
        ) : (
          // Paper Sets
          <div className="space-y-8">
            <div className="text-center">
              <button
                onClick={() => setSelectedSubject(null)}
                className="text-primary-600 hover:text-primary-700 mb-4 inline-flex items-center"
              >
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back to Subjects
              </button>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                {selectedExam.subjects.find(s => s.id === selectedSubject)?.name} Paper Sets
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Select a paper set to start your test
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {selectedExam.subjects
                .find(s => s.id === selectedSubject)
                ?.paperSets.map((set) => (
                  <button
                    key={set.id}
                    onClick={() => router.push(`/tests/${selectedExam.id}/${selectedSubject}/${set.id}`)}
                    className="p-6 bg-white dark:bg-gray-800 rounded-2xl shadow-custom hover:shadow-custom-lg transition-all duration-200"
                  >
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                      {set.name}
                    </h3>
                    <div className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                      <p>Questions: {set.questionsCount}</p>
                      <p>Duration: {set.duration} minutes</p>
                      <p>Difficulty: {set.difficulty}</p>
                    </div>
                  </button>
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
} 