export default function AboutPage() {
  return (
    <div className="bg-gradient-to-b from-primary-50 to-white dark:from-gray-900 dark:to-gray-800">
      {/* Hero Section */}
      <section className="pt-16 pb-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center space-y-4">
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
              About MCQ Exam Platform
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-400">
              Empowering students with comprehensive online testing solutions
            </p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-white dark:bg-gray-800">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Our Mission</h2>
              <p className="text-gray-600 dark:text-gray-400">
                To provide accessible, high-quality practice tests that help students achieve their academic goals and prepare for success.
              </p>
            </div>

            <div className="grid gap-8">
              {missionPoints.map((point, index) => (
                <div 
                  key={index}
                  className="p-6 rounded-2xl bg-primary-50 dark:bg-gray-700 shadow-custom"
                >
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    {point.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">{point.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Vision Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
              Our Vision
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400 mb-12">
              We envision a future where quality education and assessment tools are accessible to every student, 
              regardless of their location or background. Through our platform, we aim to revolutionize 
              the way students prepare for their academic challenges.
            </p>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="p-6 rounded-2xl bg-white dark:bg-gray-700 shadow-custom">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  Innovation
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Continuously improving our platform with the latest educational technologies
                </p>
              </div>
              <div className="p-6 rounded-2xl bg-white dark:bg-gray-700 shadow-custom">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  Accessibility
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Making quality education resources available to students worldwide
                </p>
              </div>
              <div className="p-6 rounded-2xl bg-white dark:bg-gray-700 shadow-custom">
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  Excellence
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Maintaining high standards in our educational content and platform
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

const missionPoints = [
  {
    title: 'Quality Education',
    description: 'We believe in providing high-quality educational resources that are accessible to everyone.'
  },
  {
    title: 'Continuous Improvement',
    description: 'Our platform is constantly evolving to meet the changing needs of students and educators.'
  },
  {
    title: 'Student Success',
    description: 'We measure our success by the achievements of our students and their academic growth.'
  }
] 