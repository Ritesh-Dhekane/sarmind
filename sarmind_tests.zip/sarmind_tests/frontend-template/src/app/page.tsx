import Image from "next/image";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white dark:from-gray-900 dark:to-gray-800">
      {/* Hero Section */}
      <section className="pt-20 pb-32">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto space-y-6">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white">
              Test Your Knowledge with{' '}
              <span className="text-primary-600">MCQ Exam</span>
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-400">
              Practice and improve your skills with our comprehensive multiple choice question platform.
              Take tests, track your progress, and achieve your learning goals.
            </p>
            <div className="flex justify-center gap-4">
              <a
                href="/tests"
                className="px-8 py-3 bg-primary-600 text-white rounded-xl font-medium hover:bg-primary-700 transition-all duration-200 transform hover:-translate-y-0.5"
              >
                Start Testing
              </a>
              <a
                href="/about"
                className="px-8 py-3 border-2 border-primary-600 text-primary-600 rounded-xl font-medium hover:bg-primary-50 transition-all duration-200"
              >
                Learn More
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white dark:bg-gray-800">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-900 dark:text-white">
            Why Choose MCQ Exam?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="p-6 rounded-2xl bg-white dark:bg-gray-700 shadow-custom hover:shadow-custom-lg transition-shadow duration-200"
              >
                <div className="w-12 h-12 bg-primary-100 dark:bg-primary-900 rounded-xl flex items-center justify-center mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2 text-gray-900 dark:text-white">
                  {feature.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-20 bg-primary-50 dark:bg-gray-900">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index} className="space-y-2">
                <div className="text-4xl font-bold text-primary-600">{stat.value}</div>
                <div className="text-gray-600 dark:text-gray-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
              Ready to Start Your Journey?
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              Join thousands of students who are already improving their knowledge with MCQ Exam.
            </p>
            <a
              href="/signup"
              className="inline-block px-8 py-3 bg-primary-600 text-white rounded-xl font-medium hover:bg-primary-700 transition-all duration-200 transform hover:-translate-y-0.5"
            >
              Create Free Account
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}

const features = [
  {
    title: 'Comprehensive Tests',
    description: 'Access a wide range of subjects and difficulty levels to match your learning needs.',
    icon: <DocumentIcon />
  },
  {
    title: 'Progress Tracking',
    description: 'Monitor your performance and track improvements over time with detailed analytics.',
    icon: <ChartIcon />
  },
  {
    title: 'Instant Results',
    description: 'Get immediate feedback and detailed explanations for each question.',
    icon: <ClockIcon />
  }
]

const stats = [
  { value: '10,000+', label: 'Questions' },
  { value: '50+', label: 'Test Categories' },
  { value: '5,000+', label: 'Students' },
  { value: '95%', label: 'Satisfaction Rate' }
]

function DocumentIcon() {
  return (
    <svg className="w-6 h-6 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
  )
}

function ChartIcon() {
  return (
    <svg className="w-6 h-6 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
    </svg>
  )
}

function ClockIcon() {
  return (
    <svg className="w-6 h-6 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
  )
}
