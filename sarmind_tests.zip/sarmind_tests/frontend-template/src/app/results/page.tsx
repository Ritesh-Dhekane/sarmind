'use client'

import { useSearchParams, useRouter } from 'next/navigation'

export default function ResultsPage() {
  const searchParams = useSearchParams()
  const router = useRouter()
  
  const score = parseInt(searchParams.get('score') || '0')
  const total = parseInt(searchParams.get('total') || '0')
  const percentage = Math.round((score / total) * 100)

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-50 to-white dark:from-gray-900 dark:to-gray-800 py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-custom p-8 text-center">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">
              Test Results
            </h1>
            
            <div className="mb-8">
              <div className="text-6xl font-bold text-primary-600 mb-2">
                {percentage}%
              </div>
              <p className="text-xl text-gray-600 dark:text-gray-400">
                You scored {score} out of {total} questions correctly
              </p>
            </div>

            <div className="space-y-4">
              <button
                onClick={() => router.push('/tests')}
                className="w-full px-6 py-3 bg-primary-500 text-white rounded-xl hover:bg-primary-600 transition-colors"
              >
                Take Another Test
              </button>
              <button
                onClick={() => router.push('/')}
                className="w-full px-6 py-3 border-2 border-primary-500 text-primary-600 rounded-xl hover:bg-primary-50 dark:hover:bg-primary-900/20 transition-colors"
              >
                Back to Home
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
} 