<template>
  <Quiz />
</template>

<script>
import Quiz from "@/components/Quiz.vue"; // Use @ instead of relative path

export default {
  components: { Quiz },
};
</script>
